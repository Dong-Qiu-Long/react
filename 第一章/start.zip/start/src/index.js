import React from 'react';
import ReactDOM from 'react-dom';
ReactDOM.render(<div>1</div>,document.getElementById('root'));